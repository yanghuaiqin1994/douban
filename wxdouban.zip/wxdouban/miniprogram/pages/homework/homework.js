const db = wx.cloud.database();
// pages/homework/homework.js
Page({
  onChange(event) {
    wx.showToast({
      icon: 'none',
      title: `当前值：${event.detail}`
    });
  },

  /**
   * 页面的初始数据
   */
  data: {
    list:[]
  },
  showPic:function(){
    //获取myphoto所有合集
    db.collection("myphoto").get().then(res=>{
      console.log(res)
      var list = res.data;
      this.setData({
        list:list
      })
    }).catch(err=>{
      console.log(err)
    })
  },
  myupload:function(){
    //此函数负责选中图片并且上传至云存储
    //上传成功将failID保存myphoto集合中
    //1.选择一张图片
    wx.chooseImage({
      count:1,//选一张图片
      sizeType:["original","compressed"],//原图 压缩图
      sourceType:["album","camera"],//相册 相机
      success: function(res) {
        //选择成功
        console.log(res)
        //1.1选择图片成功后将选中的图片上传至云存储
        //1.1.1上传成功将failID保存至maphoto集合
        //2上传图片
        //2.1获取选中图片
        var file = res.tempFilePaths[0];
        //2.2给图片起新名字
        var newFile = new Date().getTime()+".jpg"
        console.log(file)
        console.log(newFile)
        //2.3上传图片
        wx.cloud.uploadFile({//上传
          cloudPath:newFile,//新文件名
          filePath:file,//选中图片名
          success:(res)=>{
            console.log(res)
            var fId = res.fileID;
            db.collection("myphoto").add({//向myphoto添加一条数据
              data:{fileID:fId},
              success:function(res){//成功
                console.log(res)
              },
              fail:function(err){//失败
                console.log(err)
              }
            })
          },
          fail:(err)=>{
            console.log(err)
          }
        })
      },
      fail:function(err){
        //选择失败
        console.log(err)
      }
    })
      
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})