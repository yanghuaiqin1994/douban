//6.1初始化数据库
const db = wx.cloud.database({
  //指定环境id
  env:"web-test-01-et49h"
})
// pages/comment/comment.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    value:"", //输入框中用户输入的内容
    score:0,
    movieid:0,//保存电影id
    detail:{}, //保存电影的信息
    images:[], //保存选中的图片
    fileIDS:[]  //上传成功保存的fileID的值
  },
  mysubmit:function(){
    //功能:将我们选中的图片上传到云存储中
    //1.在data添加属性fileIDS:[]
    //2.显示加载动画提示框“正在提交中”
    wx.showLoading({
      title: '正在提交中...',
    })
    //3.上传到云存储
      //3.1创建promise数组 用来保存promise对象
      var promiseArr = [];
      //3.2创建一个循环，遍历选中的图片
      for(var i=0;i<this.data.images.length;i++){
        //3.3创建promise对象
        //promise对象负责一张图片的上传任务
        //并且将图片fileid保存数组中
        promiseArr.push(new Promise((resolve,reject)=>{
          //3.3.1获取当前的图片
          var item = this.data.images[i];
          //3.3.2创建一个正则表达式 拆分文件的后缀名
          var suffix = /\.\w+$/.exec(item)[0];
          //3.3.3上传图片 并且将fileID保存数组
          //新文件名=时间+随机数+后缀
          var newFile = new Date().getTime()+Math.floor(Math.random()*9999)+suffix;
          wx.cloud.uploadFile({
            //3.3.4为图片创建一个新的文件名
            cloudPath:newFile, //新文件名
            filePath:item,  //选中文件
            success:res => {//上传成功
              //3.3.5上传成功拼接fileID
              var fid = res.fileID;
              var ids = this.data.fileIDS.concat(fid)
              this.setData({
                fileIDS:ids
              })
              //3.3.6将当前promise任务追加任务列表中
              resolve();
              //3.3.7上传时报输出错误消息
              console.log()
            },
            fail:err => {//失败
              console.log(err)
            }
          })      
        }));//promise end
      }//for end
    //功能2:将云存储的fileid一次性存储云数据库集中
    //4.在云数据库当中创建一个集合 comment 此集合用于保存评论的内容和内容id
    //5.等待数组中所有promise任务执行结束 此时promise对象执行完毕
    Promise.all(promiseArr).then(res => {
    //6.回调函数中
    //6.1在程序最顶端初始化数据库
    //7.将评论内容 分数 电影id 上传图片所有id添加集合中
    db.collection("comment")//指定集合
    .add({//添加记录
      data:{//数据
        content:this.data.value,  //评论内容
        score:this.data.score,  //评论分数
        movieid:this.data.movieid,  //电影id
        fileIds:this.data.fileIDS  //图片fileID
      }
    }).then(res => {
      console.log(res)
      //8.隐藏加载提示框
      wx.hideLoading();
      //9.显示提示框“发表成功”
      wx.showToast({
        title: '发表成功',
      })
    }).catch(err => {
       //10.添加集合失败
      //11隐藏加载提示框
      wx.hideLoading()
      //12显示提示框“评论失败”
      wx.showToast({
        title: '发表失败',
      })
    })
    })
  },
  selectImage:function(){
    //请用户选择九张图片，保存到data中
    //1.在data中添加属性images
    wx.chooseImage({
      count:9,
      sizeType:["original","compressed"],
      sourceType:["album","camera"],
      success: (res)=> {
        var files = res.tempFilePaths
        //2调用wx.chooseImages选中图片
        //3将选中的九张图片保存到images中
        this.setData({
          images:files
        })
      },
    })
    
  },
  loadMoe:function(){
    var id = this.data.movieid;
    wx.showLoading({
      title: '加载中...',
    })
    wx.cloud.callFunction({//发送请求获取云函数的返回数据
    //接收电影列表传递的参数id
    //显示数据加载提示框
    //调用云函数
      name:"getDetail3",//云函数名字
      data:{id:id}
    }).then(res => {
      console.log(res)
      //获取云函数返回结果
        var obj = JSON.parse(res.result)
        console.log(obj)
        this.setData({
          detail: obj
        })
      }).catch(err => {
        console.log(err)
      })
      //将云函数返回的字符串转js对象
      //将js对象保存到detail对象当中
      //隐藏加载提示框
      wx.hideLoading();
   
  },
  onContentChange:function(event) {
    // event.detail 为当前输入的值
    console.log(event.detail);//detail 用户输入的内容
      this.setData({
        value: event.detail
      });
  },
  onScoreChange:function(e){//用户打分对应的事件处理函数
    this.setData({//获得用户现在输入的分数
      score:e.detail
    })
    console.log(e.detail)
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options)
    //将电影列表组件传递参数 id保存到data中movieid
    this.setData({
      movieid:options.id
    })
    this.loadMoe()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})