// pages/home/home.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    show: false,
    list:[],
    listimg:[],
    animationData: {}, //公告动画
    announcementText: "营业时间从早上10点到晚上8点",//公告内容
  },
  //监听页面高度(上滑或者下滑)
  onPageScroll: function (obj) {
    console.log(obj)
    if (obj.scrollTop > 363) {
      this.setData({
        goTopStatus: true
      })
    }
  },
  goToTop: function () {
    wx.pageScrollTo({
      scrollTop: 0,
    })
    this.setData({
      goTopStatus: false
    })
  },
  jumpComment:function(e){
    //用户点击详情按钮后跳转详情组件
    //wx.redirectTo({  
      //url: '/pages/comment/comment',
    //})
    //获取自定义属性
    var id = e.target.dataset.id;
    //保留并且跳转，特点 允许回退
    wx.navigateTo({
      url: '/pages/comment/comment?id='+id,
    })
    //获取电影ID，并且跳转组件时传递comment组件，在comment获取id

  },
  loadMore:function(){
    //调用云函数
    wx.cloud.callFunction({
      name:"movielist3",
      data:{
        start:this.data.list.length,
        count:10
        }
    }).then(res=>{
      //结果是查询字符串
      //将字符串转为JS对象
      console.log(res)
      var obj = JSON.parse(res.result)
      console.log(obj)
      //subjects电影列表
      //保留上一页的电影列表
      //保存电影列表数据
      var imgs = obj.subjects.slice(0,4)
      console.log(imgs)
      var rows = obj.subjects;
      //将电影列表数据进行数组拼接
      rows = this.data.list.concat(rows)
      //拼接后的结果保存起来
      this.setData({
        list:rows,
        listimg:imgs
      })
      console.log(obj.subjects)
      //接收返回数据 list
      //在home.wxml创建循环
      //遍历电影信息
      //电影图片 small
      //电影标题
      //电影评分
      //电影导演
      //电影年份
      //电影主演
    }).catch(err=>{
      console.log(err)
    })
    //将返回结果保存
  },
  onChange(event) {
    this.setData({
      value: event.detail
    });
  },
  onClose() {
    this.setData({ show: false });

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.loadMore()
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    console.log(123)
    //发送请求下载下一页的数据
    this.loadMore();
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})