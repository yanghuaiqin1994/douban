export declare const transition: (showDefaultValue: boolean) => void;
