// 云函数入口文件
const cloud = require('wx-server-sdk')
cloud.init()
/*
// 云函数入口函数
exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext()

  return {
    event,
    openid: wxContext.OPENID,
    appid: wxContext.APPID,
    unionid: wxContext.UNIONID,
  }
}
*/
//发送ajax请求获取豆瓣电影详情
//1.引入第三方ajax库 request-promise
var rp = require("request-promise");
//2.创建，main函数
exports.main = async (event,context) => {
  //3.向豆瓣发送请求
  var url = `http://api.douban.com/v2/movie/subject/${event.id}?apikey=0df993c66c0c636e29ecbb5344252a4a`;
  //4.返回豆瓣电影详情的内容
  return rp(url).then(res =>{//返回
    return res;//函数执行成功 结果
  }).catch(err => {
    return err;//执行失败返回的结果
  })
}
